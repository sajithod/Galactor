﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace GalacticDirectory.Data.Migrations
{
    public partial class Charactermodified : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "BirthYear",
                table: "Characters",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "EyeColor",
                table: "Characters",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Gender",
                table: "Characters",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "HairColor",
                table: "Characters",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "Height",
                table: "Characters",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Mass",
                table: "Characters",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "SkinColor",
                table: "Characters",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "BirthYear",
                table: "Characters");

            migrationBuilder.DropColumn(
                name: "EyeColor",
                table: "Characters");

            migrationBuilder.DropColumn(
                name: "Gender",
                table: "Characters");

            migrationBuilder.DropColumn(
                name: "HairColor",
                table: "Characters");

            migrationBuilder.DropColumn(
                name: "Height",
                table: "Characters");

            migrationBuilder.DropColumn(
                name: "Mass",
                table: "Characters");

            migrationBuilder.DropColumn(
                name: "SkinColor",
                table: "Characters");
        }
    }
}
