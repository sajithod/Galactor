﻿using System;
using System.Collections.Generic;
using System.Linq;
using GalacticDirectory.Common.Models;
using Microsoft.Extensions.Logging;
namespace GalacticDirectory.Data.Seed
{
    public static class SeedData
    {
        static string[] Haircolor = { "Black", "White", "Grey", "Blond" };
        static string[] SkinColor = { "Black", "White", "Yellow", "Wheat", "Dark" };
        static string[] EyeColor = { "Black", "Blue", "Brown", "Green" };
        static string[] Names =
       {
            "Marcus,HighTower,Male,acmecorp.com",
            "Jesse,Smith,Female,gmail.com",
            "Albert,Einstein,Male,outlook.com",
            "Dan,Wahlin,Male,yahoo.com",
            "Ward,Bell,Male,gmail.com",
            "Brad,Green,Male,gmail.com",
            "Igor,Minar,Male,gmail.com",
            "Miško,Hevery,Male,gmail.com",
            "Michelle,Avery,Female,acmecorp.com",
            "Heedy,Wahlin,Female,hotmail.com",
            "Thomas,Martin,Male,outlook.com",
            "Jean,Martin,Female,outlook.com",
            "Robin,Cleark,Female,acmecorp.com",
            "Juan,Paulo,Male,yahoo.com",
            "Gene,Thomas,Male,gmail.com",
            "Pinal,Dave,Male,gmail.com",
            "Fred,Roberts,Male,outlook.com",
            "Tina,Roberts,Female,outlook.com",
            "Cindy,Jamison,Female,gmail.com",
            "Robyn,Flores,Female,yahoo.com",
            "Jeff,Wahlin,Male,gmail.com",
            "Danny,Wahlin,Male,gmail.com",
            "Elaine,Jones,Female,yahoo.com"
        };

        private static string[] SplitValue(string val)
        {
            return val.Split(',');
        }
        public static void SeedDatabase(this StarWarsContext db)
        {
            db._logger.LogInformation("Seeding database");

            // episodes
            var newhope = new Episode { Id = 4, Title = "NEWHOPE" };
            var empire = new Episode { Id = 5, Title = "EMPIRE" };
            var jedi = new Episode { Id = 6, Title = "JEDI" };
            var episodes = new List<Episode>
            {
                newhope,
                empire,
                jedi,
            };
            if (!db.Episodes.Any())
            {
                db._logger.LogInformation("Seeding episodes");
                db.Episodes.AddRange(episodes);
                db.SaveChanges();
            }

            // planets
            var tatooine = new Planet { Id = 1, Name = "Tatooine" };
            var alderaan = new Planet { Id = 2, Name = "Alderaan" };
            var planets = new List<Planet>
            {
                tatooine,
                alderaan
            };
            if (!db.Planets.Any())
            {
                db._logger.LogInformation("Seeding planets");
                db.Planets.AddRange(planets);
                db.SaveChanges();
            }

            // humans
            var luke = new Human
            {
                Id = 1000,
                Name = "Luke Skywalker",
                HairColor = "Black",
                EyeColor = "Yellow",
                SkinColor = "Blue",
                Gender = "Female",
                BirthYear = "BB77",
                Height = 126,
                Mass = 200,
                CharacterEpisodes = new List<CharacterEpisode>
                {
                    new CharacterEpisode { Episode = newhope },
                    new CharacterEpisode { Episode = empire },
                    new CharacterEpisode { Episode = jedi }
                },
                HomePlanet = tatooine
            };
            var vader = new Human
            {
                Id = 1001,
                Name = "Darth Vader",
                HairColor = "Black",
                EyeColor = "Yellow",
                SkinColor = "Blue",
                Gender = "Female",
                BirthYear = "BB77",
                Height = 126,
                Mass = 200,
                CharacterEpisodes = new List<CharacterEpisode>
                {
                    new CharacterEpisode { Episode = newhope },
                    new CharacterEpisode { Episode = empire },
                    new CharacterEpisode { Episode = jedi }
                },
                HomePlanet = tatooine
            };
            var han = new Human
            {
                Id = 1002,
                Name = "Han Solo",
                HairColor = "Black",
                EyeColor = "Yellow",
                SkinColor = "Blue",
                Gender = "Female",
                BirthYear = "BB77",
                Height = 126,
                Mass = 200,
                CharacterEpisodes = new List<CharacterEpisode>
                {
                    new CharacterEpisode { Episode = newhope },
                    new CharacterEpisode { Episode = empire },
                    new CharacterEpisode { Episode = jedi }
                },
                HomePlanet = tatooine
            };
            var leia = new Human
            {
                Id = 1003,
                Name = "Leia Organa",
                HairColor = "Black",
                EyeColor = "Yellow",
                SkinColor = "Blue",
                Gender = "Male",
                BirthYear = "BB77",
                Height = 126,
                Mass = 200,
                CharacterEpisodes = new List<CharacterEpisode>
                {
                    new CharacterEpisode { Episode = newhope },
                    new CharacterEpisode { Episode = empire },
                    new CharacterEpisode { Episode = jedi }
                },
                HomePlanet = alderaan
            };
            var tarkin = new Human
            {
                Id = 1004,
                Name = "Wilhuff Tarkin",
                HairColor = "Black",
                EyeColor = "Yellow",
                SkinColor = "Blue",
                Gender = "Male",
                BirthYear = "BB77",
                Height = 126,
                Mass = 200,
                CharacterEpisodes = new List<CharacterEpisode>
                {
                    new CharacterEpisode { Episode = newhope }
                },
            };
            var humans = new List<Human>
                {
                luke,
                vader,
                han,
                leia,
                tarkin
                 };
            if (!db.Humans.Any())
            {
                db._logger.LogInformation("Seeding humans");
                db.Humans.AddRange(humans);
                db.SaveChanges();
            }



            // droids
            var threepio = new Droid
            {
                Id = 2000,
                Name = "C-3PO",
                HairColor = "Black",
                EyeColor = "Yellow",
                SkinColor = "Blue",
                Gender = "Male",
                BirthYear = "BB77",
                Height = 126,
                Mass = 200,
                CharacterEpisodes = new List<CharacterEpisode>
                {
                    new CharacterEpisode { Episode = newhope },
                    new CharacterEpisode { Episode = empire },
                    new CharacterEpisode { Episode = jedi }
                },
                PrimaryFunction = "Protocol"
            };
            var artoo = new Droid
            {
                Id = 2001,
                Name = "R2-D2",
                HairColor = "Black",
                EyeColor = "Yellow",
                SkinColor = "Blue",
                Gender = "Male",
                BirthYear = "BB77",
                Height = 126,
                Mass = 200,
                CharacterEpisodes = new List<CharacterEpisode>
                {
                    new CharacterEpisode { Episode = newhope },
                    new CharacterEpisode { Episode = empire },
                    new CharacterEpisode { Episode = jedi }
                },
                PrimaryFunction = "Astromech"
            };
            var droids = new List<Droid>
            {
                threepio,
                artoo
            };
            if (!db.Droids.Any())
            {
                db._logger.LogInformation("Seeding droids");
                db.Droids.AddRange(droids);
                db.SaveChanges();
            }

            // update character's friends
            luke.CharacterFriends = new List<CharacterFriend>
            {
                new CharacterFriend { Friend = han },
                new CharacterFriend { Friend = leia },
                new CharacterFriend { Friend = threepio },
                new CharacterFriend { Friend = artoo }
            };
            vader.CharacterFriends = new List<CharacterFriend>
            {
                new CharacterFriend { Friend = tarkin }
            };
            han.CharacterFriends = new List<CharacterFriend>
            {
                new CharacterFriend { Friend = luke },
                new CharacterFriend { Friend = leia },
                new CharacterFriend { Friend = artoo }
            };
            leia.CharacterFriends = new List<CharacterFriend>
            {
                new CharacterFriend { Friend = luke },
                new CharacterFriend { Friend = han },
                new CharacterFriend { Friend = threepio },
                new CharacterFriend { Friend = artoo }
            };
            tarkin.CharacterFriends = new List<CharacterFriend>
            {
                new CharacterFriend { Friend = vader }
            };
            threepio.CharacterFriends = new List<CharacterFriend>
            {
                new CharacterFriend { Friend = luke },
                new CharacterFriend { Friend = han },
                new CharacterFriend { Friend = leia },
                new CharacterFriend { Friend = artoo }
            };
            artoo.CharacterFriends = new List<CharacterFriend>
            {
                new CharacterFriend { Friend = luke },
                new CharacterFriend { Friend = han },
                new CharacterFriend { Friend = leia }
            };
            var characters = new List<Character>
            {
                luke,
                vader,
                han,
                leia,
                tarkin,
                threepio,
                artoo
            };
            if (!db.CharacterFriends.Any())
            {
                db._logger.LogInformation("Seeding character's friends");
                db.Characters.UpdateRange(characters);
                db.SaveChanges();
            }

            // update episode's heroes
            newhope.Hero = artoo;
            empire.Hero = luke;
            jedi.Hero = artoo;
            db._logger.LogInformation("Seeding episode's heroes");
            db.SaveChanges();

            // Random Human Data
            if (db.Episodes.Any())
                return;
            var random = new Random();
            for (int i = 0; i < 100; i++)
            {
                var randname = random.Next(0, 20);
                var randhair = random.Next(0, 3);
                var randskin = random.Next(0, 4);
                var randeye = random.Next(0, 3);
                var human = new Human
                {
                    Id = 4500 + i,
                    Name = SplitValue(Names[randname])[0] + " " + SplitValue(Names[randname])[1],
                    HairColor = SplitValue(Haircolor[randhair])[0],
                    EyeColor = SplitValue(EyeColor[randeye])[0],
                    SkinColor = SplitValue(SkinColor[randskin])[0],
                    Gender = SplitValue(Names[randname])[2],
                    BirthYear = "BB77",
                    Height = random.Next(160, 200),
                    Mass = random.Next(200, 300),

                };
                db._logger.LogInformation("Adding Random Humans");
                db.Humans.Add(human);
                db.SaveChanges();
            }

        }
    }


}
