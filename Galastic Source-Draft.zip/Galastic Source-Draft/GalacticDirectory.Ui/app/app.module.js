'use strict';

angular.module('app', [
  'ngAnimate',
  'ngRoute',
  'ui.bootstrap',
  'core',
  'personUpdate',
  'personDetail',
  'personList'
]);
