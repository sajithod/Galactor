'use strict';

angular.
  module('personList').
  component('personList', {
    templateUrl: 'person-list/person-list.template.html',
      controller: ['$location', '$filter', '$window','Person',
        function PersonListController($location, $filter, $window,personService) {
            var vm = this;

            vm.listDisplayModeEnabled = true;
            vm.people = [];
            vm.filteredCharacters = [];
            vm.orderby = 'name';
            vm.searchText = null;
            vm.filteredCount = 0;

            //paging
            vm.totalRecords = 0;
            vm.pageSize = 12; //set to 3 if there is no data
            vm.currentPage = 1;

          //Person.query().then(function success(response) {
          //    vm.people = response.data;
          //    console.log(angular.toJson(vm.people));
          //}, function error(response) {
          //    console.error(response)
          //});
            function init() {
                 getCharacters();
            }
            vm.pageChanged = function (page) {
                vm.currentPage = page;
                getCharacters();
            };

            vm.searchTextChanged = function () {
                filterCharacters(vm.searchText);
            };

            function filterCharacters(filterText) {
               // vm.filteredCharacters = $filter("search")(vm.people, filterText);
                vm.filteredCharacters = filter(vm.people, filterText);
                vm.filteredCount = vm.filteredCharacters.length;
            }
            function filter(people, filterValue) {
                if (!filterValue) return people;

                var matches = [];
                filterValue = filterValue.toLowerCase();
                for (var i = 0; i < people.length; i++) {
                    var cust = people[i];
                    console.log(cust.name.toLowerCase());
                    if (cust.name.toLowerCase().indexOf(filterValue) > -1 ) {

                        matches.push(cust);
                    }
                }
                return matches;
            };
            function getCharacters() {
                personService.query(vm.currentPage, vm.pageSize)
                    .then(function (data) {
                        vm.totalRecords = data.totalRecords;
                        vm.people = data.results;
                        filterCharacters(''); //Trigger initial filter

                    }, function (error) {
                        $window.alert('Sorry, an error occurred: ' + error);
                    });
            }

            init();
      }
    ]
  });
