'use strict';

angular.module('personList', ['core.person']);
