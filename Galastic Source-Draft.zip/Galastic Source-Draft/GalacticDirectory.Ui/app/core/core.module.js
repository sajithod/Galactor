'use strict';

// Define the `core` module
angular.module('core', ['core.person']);
