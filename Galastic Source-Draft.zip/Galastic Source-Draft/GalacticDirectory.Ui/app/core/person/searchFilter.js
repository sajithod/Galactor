﻿    angular.
        module('core.person').
        service('searchFilter', function () {

            var searchFilter = function () {

                return function (people, filterValue) {
                    if (!filterValue) return people;

                    var matches = [];
                    filterValue = filterValue.toLowerCase();
                    for (var i = 0; i < people.length; i++) {
                        var cust = people[i];
                        if (cust.name.toLowerCase().indexOf(filterValue) > -1 ||
                            cust.gender.toLowerCase().indexOf(filterValue) > -1 ||
                            cust.birthYear.toLowerCase().indexOf(filterValue) > -1 ||
                            cust.primaryFuntion.toLowerCase().indexOf(filterValue) > -1) {

                            matches.push(cust);
                        }
                    }
                    return matches;
                };
            }
        });