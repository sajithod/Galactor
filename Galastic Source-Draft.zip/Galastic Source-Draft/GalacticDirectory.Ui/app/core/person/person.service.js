'use strict';

const testData = {
  "id": 1,
  "name": "Luke Skywalker",
  "height": "172",
  "mass": "77",
  "hair_color": "blond",
  "skin_color": "fair",
  "eye_color": "blue",
  "birth_year": "19BBY",
  "gender": "male"
};

angular.
  module('core.person').
  service('Person', 
        function ($http) {
            var serviceBase = 'http://localhost:5000/api/character/';
            
            this.query = function (pageIndex, pageSize) {
                return getPagedResource('GetAllCharactersPaged', pageIndex, pageSize);
            };

            this.get = function (id) {
                return $http.get(serviceBase + parseInt(id)).then(function (results) {
                    return results.data;
                });
            };
            this.set = function (personId, person) {
                return $http.put(serviceBase + parseInt(personId), person).then(function (status) {
                    return status.data;
                });
            };
            function getPagedResource(baseResource, pageIndex, pageSize) {
                var resource = baseResource;
                resource += (arguments.length == 3) ? buildPagingUri(pageIndex, pageSize) : '';
                return $http.get(serviceBase + resource).then(function (response) {
                    var characters = response.data;
                
                    return {
                        totalRecords: characters.totalCount,
                        results: characters.data
                    };
                });
            }

            function buildPagingUri(pageIndex, pageSize) {
                var uri = '?pagenumber=' + pageIndex + '&pagesize=' + pageSize;
                return uri;
            }

    




        }
  );
