'use strict';

angular.module('core.person', ['ngResource']);
