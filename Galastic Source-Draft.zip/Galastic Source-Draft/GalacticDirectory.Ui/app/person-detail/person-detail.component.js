'use strict';

angular.
  module('personDetail').
  component('personDetail', {
    templateUrl: 'person-detail/person-detail.template.html',
    controller: ['$routeParams', 'Person',
      function PersonDetailController($routeParams, Person) {
          var self = this;
          var id = ($routeParams.personId) ? parseInt($routeParams.personId) : 0
          Person.get(id).then(function (result) {
              self.person = result;
          });
      }
    ]
  });
