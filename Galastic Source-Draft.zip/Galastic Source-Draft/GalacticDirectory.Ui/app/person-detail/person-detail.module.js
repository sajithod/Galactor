'use strict';

angular.module('personDetail', [
  'ngRoute',
  'core.person'
]);
