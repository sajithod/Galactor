'use strict';

angular.
  module('personUpdate').
  component('personUpdate', {
    templateUrl: 'person-update/person-update.template.html',
    controller: ['$routeParams', '$location', 'Person',
      function PersonUpdateController($routeParams, $location, Person) {
          var self = this;
          var id = ($routeParams.personId) ? parseInt($routeParams.personId) : 0
          Person.get(id).then(function (result) {
              self.person = result;
              self.edit = {
                  "name": self.person.name,
                  "height": self.person.height,
                  "mass": self.person.mass,
                  "hair_color": self.person.hairColor,
                  "skin_color": self.person.skinColor,
                  "eye_color": self.person.eyeColor,
                  "birth_year": self.person.birthYear,
                  "gender": self.person.gender
              };
          });
 
          self.submit = function () {
              self.person = {
                  "id": id,
                  "name": self.edit.name,
                  "height": self.edit.height,
                  "mass": self.edit.mass,
                  "hairColor": self.edit.hair_color,
                  "skinColor": self.edit.skin_color,
                  "eyeColor": self.edit.eye_color,
                  "birthYear": self.edit.birth_year,
                  "gender": self.edit.gender
              };
          Person.set($routeParams.personId, self.person);
          $location.path('/');
        };
      }
    ]
  });
