'use strict';

angular.module('personUpdate', [
  'ngRoute',
  'core.person'
]);
