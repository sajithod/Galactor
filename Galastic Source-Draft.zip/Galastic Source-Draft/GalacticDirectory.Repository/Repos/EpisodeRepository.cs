﻿using GalacticDirectory.Common.Models;
using GalacticDirectory.Repository.Interfaces;
using GalacticDirectory.Data;
using Microsoft.Extensions.Logging;


namespace StarWars.Data.EntityFramework.Repositories
{
    public class EpisodeRepository : BaseRepository<Episode, int>, IEpisodeRepository
    {
        public EpisodeRepository() { }

        public EpisodeRepository(StarWarsContext db, ILogger<EpisodeRepository> logger)
            : base(db, logger)
        {
        }
    }
}
