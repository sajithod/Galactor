﻿using GalacticDirectory.Common.Models;
using GalacticDirectory.Repository.Interfaces;
using GalacticDirectory.Data;
using Microsoft.Extensions.Logging;


namespace StarWars.Data.EntityFramework.Repositories
{
    public class PlanetRepository : BaseRepository<Planet, int>, IPlanetRepository
    {
        public PlanetRepository() { }

        public PlanetRepository(StarWarsContext db, ILogger<PlanetRepository> logger)
            : base(db, logger)
        {
        }
    }
}
