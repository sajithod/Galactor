﻿using GalacticDirectory.Common.Models;

namespace GalacticDirectory.Repository.Interfaces
{
    public interface IPlanetRepository : IBaseRepository<Planet, int> { }
}
