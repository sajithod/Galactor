﻿
using GalacticDirectory.Common.Models;

namespace GalacticDirectory.Repository.Interfaces
{
    public interface IDroidRepository : IBaseRepository<Droid, int> { }
}
