﻿using GalacticDirectory.Common.Models;

namespace GalacticDirectory.Repository.Interfaces
{
    public interface IHumanRepository : IBaseRepository<Human, int> { }
}
