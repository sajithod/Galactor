﻿using System;
using System.Buffers;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GalacticDirectory.Data;
using GalacticDirectory.Data.Seed;
using GalacticDirectory.Repository.Interfaces;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Formatters;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using StarWars.Data.EntityFramework.Repositories;

namespace GalacticDirectory.Api
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddCors(o => o.AddPolicy("MyPolicy", builder =>
            {
                builder.AllowAnyOrigin()
                       .AllowAnyMethod()
                       .AllowAnyHeader();

            }));
            services.AddMySwagger();
            services.AddMvc(
                //options =>
                //{
                //    options.OutputFormatters.Clear();
                //    options.OutputFormatters.Add(new JsonOutputFormatter(new JsonSerializerSettings()
                //    {
                //        ReferenceLoopHandling = ReferenceLoopHandling.Ignore,
                //    }, ArrayPool<char>.Shared));
                //}
                )

                .AddJsonOptions(
                    options =>
                    {
                        options.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore;
                        options.SerializerSettings.PreserveReferencesHandling = PreserveReferencesHandling.Objects;
                    }

                 )
                .SetCompatibilityVersion(CompatibilityVersion.Version_2_2);
            services.AddDbContext<StarWarsContext>(options =>
            {
                // options.UseSqlServer(Configuration
                //["Data:Movies:ConnectionString"]);
                //  options.UseSqlServer(@"Server=(localdb)\\MSSQLLocalDB;Database=DVDMovie;Trusted_Connection=True;MultipleActiveResultSets=true");
            }
            );

            RegisterServices(services);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, StarWarsContext context)
        {
            app.UseCors("MyPolicy");
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            context.SeedDatabase();
            app.UseMySwagger();
            app.UseMvc();
            
        }

        public void RegisterServices(IServiceCollection services)
        {
            services.AddScoped<ICharacterRepository, CharacterRepository>();
        }
    }
}
