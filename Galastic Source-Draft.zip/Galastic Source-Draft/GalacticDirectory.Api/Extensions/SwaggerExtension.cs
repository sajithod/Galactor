﻿using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;
using System;
using System.IO;
using System.Reflection;
using System.Linq;
using Microsoft.Extensions.DependencyInjection;
using System.Collections.Generic;
using Microsoft.OpenApi.Any;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Logging;
using Swashbuckle.AspNetCore.Swagger;
using Swashbuckle.AspNetCore.SwaggerUI;

namespace GalacticDirectory.Api
{
    public static class SwaggerExtension
    {
        private const string SwaggerSection = "Swagger";

        public static void AddMySwagger(this IServiceCollection services)
        {
            var config = services.BuildServiceProvider().GetService<IConfiguration>();
            var swaggerSetting = new SwaggerSetting();
            services.Configure<SwaggerSetting>(config.GetSection(SwaggerSection));
            config.GetSection(SwaggerSection).Bind(swaggerSetting);
            services.AddSingleton<SwaggerSetting>(
            ctx => ctx.GetService<IOptions<SwaggerSetting>>().Value);

            services.AddSwaggerGen(c =>
            {
                c.AddMySwaggerDoc(swaggerSetting);
                //if (swaggerSetting.InlineHeader)
                //    c.OperationFilter<AddRequiredHeaderParameter>();
                //if (swaggerSetting.DisplayAuthorize)
                //    c.AddMyAuthentication(swaggerSetting.IsBearer);
                c.AddMyXMLComments();
                c.CustomSchemaIds(i => i.FullName);
            });
        }
        public static void AddMySwagger(this IServiceCollection services,Action<SwaggerGenOptions> addSwaggerGenAction)
        {
            var config = services.BuildServiceProvider().GetService<IConfiguration>();
            var swaggerSetting = new SwaggerSetting();
            //services.Configure<SwaggerSetting>(Configuration.GetSection(SwaggerSection));
            //Configuration.GetSection(SwaggerSection).Bind(swaggerSetting);
            services.Configure<SwaggerSetting>(config.GetSection(SwaggerSection));
            config.GetSection(SwaggerSection).Bind(swaggerSetting);
            services.AddSingleton<SwaggerSetting>(
            ctx => ctx.GetService<IOptions<SwaggerSetting>>().Value);

            services.AddSwaggerGen(c =>
            {
                c.AddMySwaggerDoc(swaggerSetting);
                if (swaggerSetting.InlineHeader)
                    c.OperationFilter<AddRequiredHeaderParameter>();
                if (swaggerSetting.DisplayAuthorize)
                    c.AddMyAuthentication(swaggerSetting.IsBearer);
                c.AddMyXMLComments();
                c.CustomSchemaIds(i => i.FullName);
                if(addSwaggerGenAction!=null)
                    addSwaggerGenAction(c);
            });
        }
        public static void AddMyXMLComments(this SwaggerGenOptions c)
        {
            var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
            var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
            if (File.Exists(xmlPath))
                c.IncludeXmlComments(xmlPath);
        }
        public static void AddMySwaggerDoc(this SwaggerGenOptions c, SwaggerSetting setting, Action<OpenApiInfo> action = null)
        {
            var info = new OpenApiInfo
            {
                Title = setting.Title,
                Version = setting.Version,
                Description = setting.Description,
                Contact = new OpenApiContact { Name = setting.TeamName, Email = setting.TeamEmail }
            };

            action?.Invoke(info);
            c.SwaggerDoc(setting.Version, info);

        }
        public static void AddMyAuthentication(this SwaggerGenOptions c, bool isBearer = false)
        {
            if (isBearer)
                AddAuthenticationScheme(c);
            else
                AddIdTokenScheme(c);
        }
        private static void AddAuthenticationScheme(SwaggerGenOptions c)
        {
            var securitySchema = new OpenApiSecurityScheme
            {
                Description = "Enter Access Token. Example: \"Bearer {Access Token}\"",
                Name = "Authorization",
                In = ParameterLocation.Header,
                Type = SecuritySchemeType.ApiKey,
                Scheme = "oauth2",
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            };
            c.AddSecurityDefinition("Bearer", securitySchema);

            var securityRequirement = new OpenApiSecurityRequirement();
            securityRequirement.Add(securitySchema, new[] { "Bearer" });
            c.AddSecurityRequirement(securityRequirement);
        }
        private static void AddIdTokenScheme(SwaggerGenOptions c)
        {
            var securitySchema = new OpenApiSecurityScheme
            {
                Description = "Enter My Id-Token. Example: \"X-IDTOKEN:{idtoken}\"",
                Name = "X-IDTOKEN",
                In = ParameterLocation.Header,
                Type = SecuritySchemeType.ApiKey,
                Scheme = "oauth2",
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "ApiKey"
                }
            };
            c.AddSecurityDefinition("ApiKey", securitySchema);

            var securityRequirement = new OpenApiSecurityRequirement();
            securityRequirement.Add(securitySchema, new[] { "ApiKey" });
            c.AddSecurityRequirement(securityRequirement);
        }
        public static void UseMySwagger(this IApplicationBuilder app)
        {
            var setting = app.ApplicationServices.GetService<IOptions<SwaggerSetting>>().Value;
            var logger = app.ApplicationServices.GetService<ILogger>();
            app.UseSwagger(
                c =>
                {
                    c.SerializeAsV2 = true;
                    var basePath = string.Empty;
                    c.PreSerializeFilters.Add((swaggerDoc, httpReq) =>
                    {
                        try
                        {
                            var param = (!string.IsNullOrEmpty(setting.DpHost) && httpReq.Host.Value.Contains(setting.DpHost)) ? "X-IDTOKEN" : "Authorization";
                           var pathCount = swaggerDoc.Paths.Count;

                            for (int i = 0; i < pathCount; i++)
                            {
                                var path = swaggerDoc.Paths.ElementAt(i);
                                if (path.Value.Operations.Count > 0)
                                {
                                    var header = path.Value.Operations.ElementAt(0).Value?.Parameters.Where(x => x.Name == param && x.In == ParameterLocation.Header);
                                    _ = path.Value.Operations.ElementAt(0).Value?.Parameters.Remove(header?.FirstOrDefault());
                                }
                            }
                        }
                        catch(Exception ex)
                        {
                            logger.LogError("Error in removing header from swagger doc", ex);
                            //Intensionally not handled
                        }
                        swaggerDoc.Servers = new List<OpenApiServer>
                        {
                                    new OpenApiServer { Url = $"{httpReq.Scheme}://{httpReq.Host.Value}{basePath}" },
                                    new OpenApiServer { Url = $"https://{httpReq.Host.Value}{basePath}" }
                        };
                    });

                });
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint(setting.SwaggerEndpoint, setting.Title);
                c.RoutePrefix = setting.RoutePrefix;

            });
        }
        public static void UseMySwagger(this IApplicationBuilder app,Action<SwaggerOptions> useSwaggerAction, Action<SwaggerUIOptions> useSwaggerUIAction )
        {
            var setting = app.ApplicationServices.GetService<IOptions<SwaggerSetting>>().Value;
            var logger = app.ApplicationServices.GetService<ILogger>();
            app.UseSwagger(
                c =>
                {
                    c.SerializeAsV2 = true;
                    var basePath = string.Empty;
                    c.PreSerializeFilters.Add((swaggerDoc, httpReq) =>
                    {
                        try
                        {
                            var param = (!string.IsNullOrEmpty(setting.DpHost) && httpReq.Host.Value.Contains(setting.DpHost)) ? "X-IDTOKEN" : "Authorization";
                            var pathCount = swaggerDoc.Paths.Count;

                            for (int i = 0; i < pathCount; i++)
                            {
                                var path = swaggerDoc.Paths.ElementAt(i);
                                if (path.Value.Operations.Count > 0)
                                {
                                    var header = path.Value.Operations.ElementAt(0).Value?.Parameters.Where(x => x.Name == param && x.In == ParameterLocation.Header);
                                    _ = path.Value.Operations.ElementAt(0).Value?.Parameters.Remove(header?.FirstOrDefault());
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            logger.LogError("Error in removing header from swagger doc", ex);
                            //Intensionally not handled
                        }
                        swaggerDoc.Servers = new List<OpenApiServer>
                        {
                                    new OpenApiServer { Url = $"{httpReq.Scheme}://{httpReq.Host.Value}{basePath}" },
                                    new OpenApiServer { Url = $"https://{httpReq.Host.Value}{basePath}" }
                        };
                    });
                    if (useSwaggerAction != null)
                        useSwaggerAction(c);
                });
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint(setting.SwaggerEndpoint, setting.Title);
                c.RoutePrefix = setting.RoutePrefix;
                if (useSwaggerUIAction != null)
                    useSwaggerUIAction(c);
            });
        }

    }

    public class AddRequiredHeaderParameter : IOperationFilter
    {

        public void Apply(OpenApiOperation operation, OperationFilterContext context)
        {
            if (operation.Parameters == null)
                operation.Parameters = new List<OpenApiParameter>();

            operation.Parameters.Add(new OpenApiParameter
            {
                Name = "Authorization",
                In = ParameterLocation.Header,
                Description = "Enter DataPower Access token \"Bearer {Access Token}\"",
                Style = ParameterStyle.Simple,
                Schema = new OpenApiSchema
                {
                    Type = "string",
                    Default = new OpenApiString("Bearer {Access Token}")
                }
            });

            operation.Parameters.Add(new OpenApiParameter
            {
                Name = "X-IDTOKEN",
                In = ParameterLocation.Header,
                Description = "Enter DataPower Id token \" {IdToken}\"",
                Schema = new OpenApiSchema
                {
                    Type = "string",
                    // Default = new OpenApiString("{Id Token}")
                    Default = new OpenApiString(Guid.NewGuid().ToString())
                }

            });
        }
    }
    public class SwaggerSetting
    {
        public string Title { get; set; }
        public string Version { get; set; }
        public string Description { get; set; }
        public string TeamName { get; set; }
        public string TeamEmail { get; set; }
        public string TeamURL { get; set; }
        public bool IsBearer { get; set; }
        public string RoutePrefix { get; set; }
        public string SwaggerEndpoint { get; set; }
        public bool InlineHeader { get; set; } = true;
        public bool DisplayAuthorize { get; set; } = false;
        public string DpHost { get; set; }

    }

    //public class YamlDocumentFilter : IDocumentFilter
    //{
    //    public void Apply(OpenApiDocument swaggerDoc, DocumentFilterContext context)
    //    {

    //        string file = AppDomain.CurrentDomain.BaseDirectory + "swagger_yaml.txt";
    //        if (!File.Exists(file))
    //        {
    //            var serializer = new  YamlDotNet.YamlSerializer();
    //            serializer.SerializeToFile(file, swaggerDoc);
    //        }

    //    }
    //}


}
