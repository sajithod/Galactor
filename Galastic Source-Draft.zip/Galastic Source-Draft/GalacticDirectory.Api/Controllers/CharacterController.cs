﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GalacticDirectory.Common.Models;
using GalacticDirectory.Repository.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Distributed;
using Newtonsoft.Json;

namespace GalacticDirectory.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CharacterController : ControllerBase
    {
        private readonly ICharacterRepository _repository;
        private readonly IDistributedCache _cache;

        public CharacterController(ICharacterRepository repository,IDistributedCache cache)
        {
            _repository = repository;
            _cache = cache;
        }
        [HttpGet]
        public async Task<IEnumerable<Character>> Get()
        {
            return await _repository.GetAll();
        }

        [HttpGet ("GetAllInfo")]
        public async Task<IEnumerable<Character>> GetAllInfo()
        {
            //check cache before feching the result
            var query=await  _repository.GetAll(new string[]{ "CharacterFriends.Friend"});
            //Store to cache before return the result
            return query;
        }

        [HttpGet("GetAllCharactersPaged")]
        public IActionResult GetAllCharactersPaged(int pagenumber, int pagesize)
        {
            //check cache before feching the result
            var paged = PagedList<Character>.ToPagedList(_repository.GetAllQueriable().OrderBy(on => on.Name),
              pagenumber,
              pagesize);
            var result = new
            {
                paged.TotalCount,
                paged.PageSize,
                paged.CurrentPage,
                paged.TotalPages,
                paged.HasNext,
                paged.HasPrevious,
                data=paged
            };
            //Store to cache before return the result
            
            return Ok(result);
        }

        [HttpGet("{id}")]
        public async Task<Character> Get(int id)
        {
            return await _repository.Get(id);
        }

        [HttpPost]
        public  async Task<Character> Post([FromBody] Character character)
        {
             _repository.Add(character);
            await _repository.SaveChangesAsync();
            return character;
        }

        [HttpPut("{id}")]
        public async void Put(int id, [FromBody] Character character)
        {
            //Create a DTO object and apply validations
             _repository.Update(character);
            
        }

        [HttpDelete("{id}")]
        public async void Delete(int id)
        {
            _repository.Delete(id);
            await _repository.SaveChangesAsync();
        }
    }
}
