﻿using System;

namespace GalacticDirectory.Common
{
    public class Class1
    {
    }
}
